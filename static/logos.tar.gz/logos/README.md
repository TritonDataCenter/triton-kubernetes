| File                        | Usage                                                     |
|:--------------------------- |:----------------------------------------------------------|
| dark.svg                    | On the Login screen when access control is enabled        |
| fail-*.svg                  | On the branded error screen (for ui.pl="rancher" only)    |
| favicon.ico                 | Browser tab favicon                                       |
| graphic.svg                 | The parachuting cow part of the image on the About screen |
| login-bg.jpg                | Background for the login screen box                       |
| main.svg                    | Top-left corner of the main header                        |
| main-loading.svg            | On the branded loading screen (for ui.pl="rancher" only)  |
| main-k8s.svg                | Top-left corner of the main header, for k8s env           |
| main-mesos.svg              | Top-left corner of the main header, for mesos env         |
| main-swarm.svg              | Top-left corner of the main header, for swarm env         |
| provider-custom.svg         | Custom "Add Host" provider                                |
| provider-local.svg          | Local "Access Control" provider                           |
| provider-orchestration.svg  | "Cattle" environment orchestration provider               |
| text.svg                    | The text part of the image on the About screen            |
